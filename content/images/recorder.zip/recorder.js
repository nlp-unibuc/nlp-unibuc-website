(() => {
  const SESSION_KEY = "psytoolkit_recorder_session_id";
  const EVENTS_KEY = "psytoolkit_recorder_events";
  const EMAIL_KEY = "psytoolkit_recorder_institutional_email";

  let sessionId = null;
  let institutionalEmail = "";
  let events = [];
  let saveTimer = null;

  function isPrintableKey(e) {
    return e.key && e.key.length === 1;
  }

  function isSensitiveField(el) {
    if (!el) return false;
    const tag = el.tagName?.toLowerCase();
    const type = el.type?.toLowerCase?.() || "";

    return (
      tag === "input" &&
      ["password", "email", "tel", "number", "credit-card"].includes(type)
    );
  }

  function csvEscape(value) {
    return JSON.stringify(value ?? "");
  }

  async function init() {
    const stored = await browser.storage.local.get([
      SESSION_KEY,
      EVENTS_KEY,
      EMAIL_KEY
    ]);

    sessionId = stored[SESSION_KEY] || crypto.randomUUID();
    events = Array.isArray(stored[EVENTS_KEY]) ? stored[EVENTS_KEY] : [];
    institutionalEmail = stored[EMAIL_KEY] || "";

    await browser.storage.local.set({
      [SESSION_KEY]: sessionId,
      [EVENTS_KEY]: events,
      [EMAIL_KEY]: institutionalEmail
    });

    createPanel();
    attachListeners();
  }

  async function saveNow() {
    await browser.storage.local.set({
      [SESSION_KEY]: sessionId,
      [EVENTS_KEY]: events,
      [EMAIL_KEY]: institutionalEmail
    });
  }

  function scheduleSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveNow, 250);
  }

  function makeRecord(e) {
    return {
      sessionId,
      institutionalEmail,
      eventType: e.type,
      key: isPrintableKey(e) ? e.key : e.key,
      code: e.code,
      printable: isPrintableKey(e),
      repeat: e.repeat || false,
      altKey: e.altKey || false,
      ctrlKey: e.ctrlKey || false,
      metaKey: e.metaKey || false,
      shiftKey: e.shiftKey || false,
      timeOrigin: performance.timeOrigin,
      performanceTime: performance.now(),
      epochTime: Date.now(),
      url: location.href,
      path: location.pathname,
      targetTag: e.target?.tagName || "",
      targetType: e.target?.type || "",
      targetName: e.target?.name || "",
      targetId: e.target?.id || "",
      valueLength:
        typeof e.target?.value === "string" ? e.target.value.length : null,
      selectionStart:
        typeof e.target?.selectionStart === "number"
          ? e.target.selectionStart
          : null,
      selectionEnd:
        typeof e.target?.selectionEnd === "number"
          ? e.target.selectionEnd
          : null
    };
  }

  function recordEvent(e) {
    if (isSensitiveField(e.target)) return;

    events.push(makeRecord(e));
    scheduleSave();
  }

  function attachListeners() {
    document.addEventListener("keydown", recordEvent, true);
    document.addEventListener("keyup", recordEvent, true);
    document.addEventListener("paste", recordEvent, true);
    document.addEventListener("cut", recordEvent, true);
    document.addEventListener("focusin", recordEvent, true);

    window.addEventListener("beforeunload", () => {
      browser.storage.local.set({
        [SESSION_KEY]: sessionId,
        [EVENTS_KEY]: events,
        [EMAIL_KEY]: institutionalEmail
      });
    });
  }

  function createPanel() {
    if (document.getElementById("psytoolkit-recorder-panel")) return;

    const panel = document.createElement("div");
    panel.id = "psytoolkit-recorder-panel";

    panel.style.position = "fixed";
    panel.style.right = "12px";
    panel.style.bottom = "12px";
    panel.style.zIndex = "2147483647";
    panel.style.background = "white";
    panel.style.color = "black";
    panel.style.border = "1px solid #999";
    panel.style.borderRadius = "8px";
    panel.style.padding = "10px";
    panel.style.fontFamily = "Arial, sans-serif";
    panel.style.fontSize = "12px";
    panel.style.boxShadow = "0 2px 10px rgba(0,0,0,0.25)";
    panel.style.minWidth = "260px";

    panel.innerHTML = `
      <div style="font-weight:bold;margin-bottom:6px;">
        PsyToolkit Recorder: ON
      </div>

      <label style="display:block;margin-bottom:4px;">
        Institutional email
      </label>

      <input
        id="psytoolkit-recorder-email"
        type="text"
        value="${institutionalEmail}"
        placeholder="name@institution.edu"
        style="width:100%;box-sizing:border-box;margin-bottom:8px;"
      />

      <div id="psytoolkit-recorder-count" style="margin-bottom:8px;">
        Events: ${events.length}
      </div>

      <button id="psytoolkit-download-csv">Download CSV</button>
      <button id="psytoolkit-download-json">Download JSON</button>
    `;

    document.documentElement.appendChild(panel);

    const emailInput = document.getElementById("psytoolkit-recorder-email");
    const count = document.getElementById("psytoolkit-recorder-count");

    emailInput.addEventListener("input", async () => {
      institutionalEmail = emailInput.value.trim();
      await browser.storage.local.set({
        [EMAIL_KEY]: institutionalEmail
      });
    });

    setInterval(() => {
      count.textContent = `Events: ${events.length}`;
    }, 500);

    document
      .getElementById("psytoolkit-download-csv")
      .addEventListener("click", downloadCSV);

    document
      .getElementById("psytoolkit-download-json")
      .addEventListener("click", downloadJSON);
  }

  async function getAllEvents() {
    await saveNow();
    const stored = await browser.storage.local.get(EVENTS_KEY);
    return Array.isArray(stored[EVENTS_KEY]) ? stored[EVENTS_KEY] : [];
  }

  async function downloadJSON() {
    const allEvents = await getAllEvents();

    const blob = new Blob([JSON.stringify(allEvents, null, 2)], {
      type: "application/json"
    });

    downloadBlob(blob, filename("json"));
  }

  async function downloadCSV() {
    const allEvents = await getAllEvents();

    if (!allEvents.length) {
      alert("No events recorded yet.");
      return;
    }

    const columns = [
      "sessionId",
      "institutionalEmail",
      "eventType",
      "key",
      "code",
      "printable",
      "repeat",
      "altKey",
      "ctrlKey",
      "metaKey",
      "shiftKey",
      "timeOrigin",
      "performanceTime",
      "epochTime",
      "url",
      "path",
      "targetTag",
      "targetType",
      "targetName",
      "targetId",
      "valueLength",
      "selectionStart",
      "selectionEnd"
    ];

    const rows = allEvents.map(row =>
      columns.map(col => csvEscape(row[col])).join(",")
    );

    const csv = [columns.join(","), ...rows].join("\n");

    const blob = new Blob([csv], {
      type: "text/csv;charset=utf-8"
    });

    downloadBlob(blob, filename("csv"));
  }

  function filename(ext) {
    const emailPart =
      institutionalEmail && institutionalEmail.includes("@")
        ? institutionalEmail.replace(/[^a-zA-Z0-9._-]/g, "_")
        : "unknown_email";

    return `psytoolkit_keystrokes_${emailPart}_${sessionId}.${ext}`;
  }

  function downloadBlob(blob, name) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();

    setTimeout(() => {
      URL.revokeObjectURL(url);
      a.remove();
    }, 1000);
  }

  init();
})();