const SESSION_KEY = "psytoolkit_session_id";
const EVENTS_KEY = "psytoolkit_events";
const EMAIL_KEY = "psytoolkit_email";

async function getSessionId() {
  const stored = await browser.storage.local.get(SESSION_KEY);
  if (stored[SESSION_KEY]) return stored[SESSION_KEY];

  const id = crypto.randomUUID();
  await browser.storage.local.set({ [SESSION_KEY]: id });
  return id;
}

async function appendEvent(event) {
  const sessionId = await getSessionId();
  const stored = await browser.storage.local.get([EVENTS_KEY, EMAIL_KEY]);

  const events = Array.isArray(stored[EVENTS_KEY])
    ? stored[EVENTS_KEY]
    : [];

  events.push({
    ...event,
    sessionId,
    institutionalEmail: stored[EMAIL_KEY] || ""
  });

  await browser.storage.local.set({ [EVENTS_KEY]: events });
}

browser.runtime.onMessage.addListener((msg) => {
  if (msg.type === "event") {
    return appendEvent(msg.event);
  }

  if (msg.type === "setEmail") {
    return browser.storage.local.set({ [EMAIL_KEY]: msg.email || "" });
  }

  if (msg.type === "getData") {
    return browser.storage.local.get([SESSION_KEY, EVENTS_KEY, EMAIL_KEY]);
  }
});