/* PsyToolkit Keystroke Recorder
 * Consent-based research recorder for PsyToolkit pages only.
 * Records timing metadata locally and provides CSV/JSON download buttons.
 */

(() => {
  "use strict";

  const STORAGE_KEY_PREFIX = "psytoolkitKeystrokeSession:";
  const CONFIG_KEY = "psytoolkitKeystrokeConfig";
  const SAVE_INTERVAL_MS = 3000;

  const DEFAULT_CONFIG = {
    enabled: true,
    institutionalEmail: "",
    recordRawPrintableKeys: true,
    startedAt: null
  };

  const state = {
    sessionId: crypto.randomUUID(),
    pageLoadedAtEpoch: Date.now(),
    events: [],
    config: { ...DEFAULT_CONFIG },
    currentTrialId: null,
    lastUrl: location.href,
    saveTimer: null,
    uiReady: false
  };

  const browserApi = typeof browser !== "undefined" ? browser : chrome;

  function now() {
    return Number(performance.now().toFixed(3));
  }

  function isoNow() {
    return new Date().toISOString();
  }

  function isEditableTarget(target) {
    if (!target) return false;
    const tag = target.tagName?.toLowerCase();
    return (
      tag === "textarea" ||
      tag === "input" ||
      target.isContentEditable === true ||
      target.closest?.("[contenteditable='true']")
    );
  }

  function isSensitiveTarget(target) {
    if (!target) return false;
    const tag = target.tagName?.toLowerCase();
    const type = String(target.type || "").toLowerCase();
    if (tag === "input" && ["password", "email", "tel", "number", "search", "url"].includes(type)) return true;
    if (target.autocomplete && String(target.autocomplete).toLowerCase().includes("password")) return true;
    return false;
  }

  function normalizeKey(event) {
    if (event.key && event.key.length === 1) return event.key;
    return event.key || "UNKNOWN";
  }

  function cssPath(el) {
    if (!el || !el.tagName) return null;
    const parts = [];
    let node = el;
    while (node && node.nodeType === Node.ELEMENT_NODE && parts.length < 5) {
      let part = node.tagName.toLowerCase();
      if (node.id) {
        part += `#${node.id}`;
        parts.unshift(part);
        break;
      }
      const cls = String(node.className || "").trim().split(/\s+/).filter(Boolean).slice(0, 2);
      if (cls.length) part += "." + cls.join(".");
      parts.unshift(part);
      node = node.parentElement;
    }
    return parts.join(" > ");
  }

  function getValueLength(target) {
    if (!target) return null;
    if (typeof target.value === "string") return target.value.length;
    const editable = target.isContentEditable ? target : target.closest?.("[contenteditable='true']");
    if (editable) return editable.textContent?.length ?? null;
    return null;
  }

  function getSelectionInfo(target) {
    if (!target) return { selectionStart: null, selectionEnd: null };
    if (typeof target.selectionStart === "number") {
      return { selectionStart: target.selectionStart, selectionEnd: target.selectionEnd };
    }
    return { selectionStart: null, selectionEnd: null };
  }

  function detectTrialId() {
    const selectors = [
      "[data-trial-id]",
      "[data-trial]",
      "#trial",
      ".trial",
      "#trialnumber",
      ".trialnumber",
      "#stimulus",
      ".stimulus"
    ];

    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (!el) continue;
      const attr = el.getAttribute("data-trial-id") || el.getAttribute("data-trial");
      const text = (attr || el.textContent || "").trim().replace(/\s+/g, " ");
      if (text) return text.slice(0, 120);
    }

    return location.pathname + location.search;
  }

  function refreshTrialId() {
    const detected = detectTrialId();
    if (detected !== state.currentTrialId) {
      state.currentTrialId = detected;
      logEvent("trial_change", null, { trialId: detected });
    }
  }

  function baseEvent(type, domEvent, extra = {}) {
    const target = domEvent?.target || null;
    const selection = getSelectionInfo(target);
    return {
      sessionId: state.sessionId,
      institutionalEmail: state.config.institutionalEmail || null,
      eventType: type,
      t: now(),
      epochMs: Date.now(),
      isoTime: isoNow(),
      trialId: state.currentTrialId,
      url: location.href,
      path: location.pathname + location.search,
      targetTag: target?.tagName?.toLowerCase?.() || null,
      targetType: target?.type || null,
      targetPath: cssPath(target),
      valueLength: getValueLength(target),
      selectionStart: selection.selectionStart,
      selectionEnd: selection.selectionEnd,
      ...extra
    };
  }

  function logEvent(type, domEvent, extra = {}) {
    if (!state.config.enabled && type !== "recorder_started" && type !== "recorder_stopped") return;
    state.events.push(baseEvent(type, domEvent, extra));
  }

  async function loadConfig() {
    const data = await browserApi.storage.local.get(CONFIG_KEY);
    state.config = { ...DEFAULT_CONFIG, ...(data[CONFIG_KEY] || {}) };
    // Auto-start on every PsyToolkit page load so participants do not need to press Start.
    state.config.enabled = true;
    state.config.recordRawPrintableKeys = true;
    if (!state.config.startedAt) state.config.startedAt = isoNow();
    await saveConfig();
  }

  async function saveConfig() {
    await browserApi.storage.local.set({ [CONFIG_KEY]: state.config });
  }

  async function saveEvents() {
    if (!state.events.length) return;
    const key = STORAGE_KEY_PREFIX + state.sessionId;
    await browserApi.storage.local.set({
      [key]: {
        sessionId: state.sessionId,
        institutionalEmail: state.config.institutionalEmail || null,
        page: location.href,
        startedAt: state.config.startedAt,
        updatedAt: isoNow(),
        events: state.events
      }
    });
  }

  function onKey(type) {
    return event => {
      if (!state.config.enabled) return;
      if (isSensitiveTarget(event.target)) return;
      refreshTrialId();
      logEvent(type, event, {
        key: normalizeKey(event),
        code: event.code || null,
        altKey: event.altKey,
        ctrlKey: event.ctrlKey,
        metaKey: event.metaKey,
        shiftKey: event.shiftKey,
        repeat: event.repeat || false,
        editableTarget: isEditableTarget(event.target)
      });
    };
  }

  function onBeforeInput(event) {
    if (!state.config.enabled) return;
    if (isSensitiveTarget(event.target)) return;
    refreshTrialId();
    logEvent("beforeinput", event, {
      inputType: event.inputType || null,
      dataClass: event.data ? "text" : null,
      dataLength: event.data ? event.data.length : 0,
      data: event.data || null
    });
  }

  function onPaste(event) {
    if (!state.config.enabled) return;
    if (isSensitiveTarget(event.target)) return;
    const pasted = event.clipboardData?.getData("text") || "";
    logEvent("paste", event, {
      pastedLength: pasted.length,
      pastedText: pasted || null
    });
  }

  function onCut(event) {
    if (!state.config.enabled) return;
    if (isSensitiveTarget(event.target)) return;
    logEvent("cut", event);
  }

  function onFocus(event) {
    if (!state.config.enabled) return;
    if (isSensitiveTarget(event.target)) return;
    logEvent("focus", event, { editableTarget: isEditableTarget(event.target) });
  }

  function onClick(event) {
    if (!state.config.enabled) return;
    if (isSensitiveTarget(event.target)) return;
    logEvent("click", event, {
      clientX: event.clientX,
      clientY: event.clientY,
      editableTarget: isEditableTarget(event.target)
    });
  }

  function escapeCsv(value) {
    if (value === null || value === undefined) return "";
    const str = typeof value === "object" ? JSON.stringify(value) : String(value);
    return '"' + str.replace(/"/g, '""') + '"';
  }

  function flattenEvents(events) {
    const preferred = [
      "sessionId", "institutionalEmail", "eventType", "t", "epochMs", "isoTime", "trialId",
      "path", "key", "code", "inputType", "dataClass", "dataLength", "repeat",
      "altKey", "ctrlKey", "metaKey", "shiftKey", "editableTarget", "targetTag", "targetType",
      "targetPath", "valueLength", "selectionStart", "selectionEnd", "pastedLength", "clientX", "clientY"
    ];
    const all = new Set(preferred);
    events.forEach(e => Object.keys(e).forEach(k => all.add(k)));
    const headers = [...preferred, ...[...all].filter(k => !preferred.includes(k))];
    return { headers, rows: events.map(e => headers.map(h => e[h])) };
  }

  function downloadBlob(filename, mime, content) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.documentElement.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function downloadCsv() {
    const { headers, rows } = flattenEvents(state.events);
    const csv = [headers.map(escapeCsv).join(","), ...rows.map(row => row.map(escapeCsv).join(","))].join("\n");
    downloadBlob(`psytoolkit-keystrokes-${state.sessionId}.csv`, "text/csv", csv);
  }

  function downloadJson() {
    const payload = {
      sessionId: state.sessionId,
      institutionalEmail: state.config.institutionalEmail || null,
      page: location.href,
      startedAt: state.config.startedAt,
      exportedAt: isoNow(),
      config: {
        recordRawPrintableKeys: true
      },
      events: state.events
    };
    downloadBlob(`psytoolkit-keystrokes-${state.sessionId}.json`, "application/json", JSON.stringify(payload, null, 2));
  }

  function makeButton(label) {
    const b = document.createElement("button");
    b.textContent = label;
    b.type = "button";
    b.style.cssText = "font:12px system-ui,sans-serif;margin:2px;padding:4px 6px;border:1px solid #444;border-radius:4px;background:#fff;color:#111;cursor:pointer;";
    return b;
  }

  function createUi() {
    if (state.uiReady || !document.documentElement) return;
    state.uiReady = true;

    const panel = document.createElement("div");
    panel.id = "psytoolkit-keystroke-recorder-panel";
    panel.style.cssText = [
      "position:fixed", "right:10px", "bottom:10px", "z-index:2147483647",
      "background:rgba(250,250,250,.96)", "border:1px solid #555", "border-radius:8px",
      "padding:8px", "box-shadow:0 2px 12px rgba(0,0,0,.25)", "color:#111",
      "font:12px system-ui,sans-serif", "max-width:260px"
    ].join(";");

    const title = document.createElement("div");
    title.textContent = "PsyToolkit keystroke recorder";
    title.style.cssText = "font-weight:700;margin-bottom:4px;";

    const status = document.createElement("div");
    status.style.cssText = "margin-bottom:6px;";

    const email = document.createElement("input");
    email.type = "email";
    email.placeholder = "Institutional email address";
    email.value = state.config.institutionalEmail || "";
    email.autocomplete = "email";
    email.style.cssText = "width:100%;box-sizing:border-box;margin:3px 0;padding:4px;";

    const note = document.createElement("div");
    note.textContent = "Recording starts automatically. Raw printable keys are recorded. Enter institutional email as soon as possible.";
    note.style.cssText = "margin:3px 0;color:#333;";

    const startStop = makeButton("Start");
    const csv = makeButton("Download CSV");
    const json = makeButton("Download JSON");

    function hasValidInstitutionalEmail() {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim());
    }

    function updateStatus() {
      const emailStatus = hasValidInstitutionalEmail() ? "email saved" : "email needed";
      status.textContent = `${state.config.enabled ? "Recording automatically" : "Paused"} · ${state.events.length} events · ${emailStatus}`;
      startStop.textContent = state.config.enabled ? "Pause" : "Resume";
      status.style.color = state.config.enabled ? "#0a6b19" : "#7a1212";
      startStop.disabled = false;
      startStop.style.opacity = "1";
    }

    async function persistUiConfig() {
      state.config.institutionalEmail = email.value.trim();
      state.config.recordRawPrintableKeys = true;
      await saveConfig();
    }

    email.addEventListener("input", () => { persistUiConfig(); updateStatus(); });
    email.addEventListener("change", persistUiConfig);

    startStop.addEventListener("click", async () => {
      await persistUiConfig();
      state.config.enabled = !state.config.enabled;
      if (state.config.enabled && !state.config.startedAt) state.config.startedAt = isoNow();
      logEvent(state.config.enabled ? "recorder_started" : "recorder_stopped", null);
      await saveConfig();
      await saveEvents();
      updateStatus();
    });

    csv.addEventListener("click", async () => { await saveEvents(); downloadCsv(); });
    json.addEventListener("click", async () => { await saveEvents(); downloadJson(); });

    panel.append(title, status, email, note, startStop, csv, json);
    document.documentElement.appendChild(panel);
    updateStatus();
    setInterval(updateStatus, 1000);
  }

  async function init() {
    await loadConfig();
    refreshTrialId();
    logEvent("recorder_started", null, { autoStart: true });
    document.addEventListener("keydown", onKey("keydown"), true);
    document.addEventListener("keyup", onKey("keyup"), true);
    document.addEventListener("beforeinput", onBeforeInput, true);
    document.addEventListener("paste", onPaste, true);
    document.addEventListener("cut", onCut, true);
    document.addEventListener("focusin", onFocus, true);
    document.addEventListener("click", onClick, true);

    const observer = new MutationObserver(() => refreshTrialId());
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });

    state.saveTimer = setInterval(saveEvents, SAVE_INTERVAL_MS);
    window.addEventListener("beforeunload", () => { saveEvents(); });

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", createUi, { once: true });
    } else {
      createUi();
    }
  }

  init().catch(err => console.error("PsyToolkit recorder init failed", err));
})();
